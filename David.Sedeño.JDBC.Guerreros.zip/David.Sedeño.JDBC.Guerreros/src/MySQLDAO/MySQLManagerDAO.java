package MySQLDAO;

public class MySQLManagerDAO {

}
