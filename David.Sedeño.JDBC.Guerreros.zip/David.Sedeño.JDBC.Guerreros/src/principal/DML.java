package principal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DML {

	private static Conexion conexion = new Conexion();

	public static void creaDATABASE() throws SQLException {
		
		 /*

		     conexion.conectar();
		     Statement cs = null;
		   try { 
		 cs = conexion.getJdbcConnection().createStatement();
		 String createdbSql=	"DROP DATABASE IF EXISTS bd_guerreros;\r\n" + "CREATE DATABASE bd_guerreros;\r\n" + "USE bd_guerreros;" ;
		   //cs.executeUpdate(createdbSql);
		 
		// System.out.println("Creada base de datos guerreros");
		   
		 
		cs.executeUpdate ( 
			 		
			 		"DROP TABLE IF EXISTS `clan`;\r\n" + 
			 		"CREATE TABLE IF NOT EXISTS `clan` (\r\n" + 
			 		"  `ID_CLAN` int(1) NOT NULL,\r\n" + 
			 		"  `NOMBRE_CLAN` varchar(20) NOT NULL,\r\n" + 
			 		"  `PAIS` char(5) NOT NULL,\r\n" + 
			 		"  PRIMARY KEY (`ID_CLAN`),\r\n" + 
			 		"  KEY `PAIS` (`PAIS`)\r\n" + 
			 		") ENGINE=InnoDB DEFAULT CHARSET=latin1;\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"INSERT INTO `clan` (`ID_CLAN`, `NOMBRE_CLAN`, `PAIS`) VALUES\r\n" + 
			 		"(1, 'VIKINGOS', 'GROEN'),\r\n" + 
			 		"(2, 'SAMURAIS', 'JAPON'),\r\n" + 
			 		"(3, 'CABALLEROS', 'GER'),\r\n" + 
			 		"(4, 'WULING', 'CHINA');\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"DROP TABLE IF EXISTS `guerrero`;\r\n" + 
			 		"CREATE TABLE IF NOT EXISTS `guerrero` (\r\n" + 
			 		"  `ID_GUERRERO` int(2) NOT NULL,\r\n" + 
			 		"  `ID_CLAN` int(1) NOT NULL,\r\n" + 
			 		"  `NOMBRE_GUERRERO` varchar(20) NOT NULL,\r\n" + 
			 		"  `EDAD` int(11) NOT NULL,\r\n" + 
			 		"  PRIMARY KEY (`ID_GUERRERO`),\r\n" + 
			 		"  KEY `ID_CLAN` (`ID_CLAN`)\r\n" + 
			 		") ENGINE=InnoDB DEFAULT CHARSET=latin1;\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"INSERT INTO `guerrero` (`ID_GUERRERO`, `ID_CLAN`, `NOMBRE_GUERRERO`, `EDAD`) VALUES\r\n" + 
			 		"(1, 1, 'ARTURO', 25),\r\n" + 
			 		"(2, 1, 'ELISA', 21),\r\n" + 
			 		"(3, 1, 'GEORGE', 34),\r\n" + 
			 		"(4, 2, 'RAGNAR', 25),\r\n" + 
			 		"(5, 2, 'KRIS', 21),\r\n" + 
			 		"(6, 2, 'THOR', 27),\r\n" + 
			 		"(7, 3, 'YATO', 22),\r\n" + 
			 		"(8, 3, 'UMI', 19),\r\n" + 
			 		"(9, 3, 'RYU', 34),\r\n" + 
			 		"(10, 4, 'JIANG', 43),\r\n" + 
			 		"(11, 4, 'LEE', 26),\r\n" + 
			 		"(12, 4, 'TIANDI', 28);\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"DROP TABLE IF EXISTS `localizacion`;\r\n" + 
			 		"CREATE TABLE IF NOT EXISTS `localizacion` (\r\n" + 
			 		"  `PAIS` char(5) NOT NULL,\r\n" + 
			 		"  `CONTINENTE` char(20) NOT NULL,\r\n" + 
			 		"  PRIMARY KEY (`PAIS`)\r\n" + 
			 		") ENGINE=InnoDB DEFAULT CHARSET=latin1;\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"INSERT INTO `localizacion` (`PAIS`, `CONTINENTE`) VALUES\r\n" + 
			 		"('CHINA', 'ASIA'),\r\n" + 
			 		"('GER', 'EUROPA'),\r\n" + 
			 		"('GROEN', 'EUROPA'),\r\n" + 
			 		"('JAPON', 'ASIA');\r\n" + 
			 		"COMMIT;\r\n" + 
			 		"\r\n" + 
			 		"\r\n" + 
			 		"");

		   }
		   catch(SQLException se) {
			   se.printStackTrace();
		   }
		   finally {
			   cs.close();
			   		
		   }
	
		 */
		
		
	}
}