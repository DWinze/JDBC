package principal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
public class DDL {
	private static Conexion conexion = new Conexion();
	private static String query;
	
	public static void consultar() throws SQLException {
		Statement statement = conexion.getJdbcConnection().createStatement();
		ResultSet set = statement.executeQuery("SELECT * FROM `guerrero`\r\n" + 
				"");
		
	}
	
	public static void insertar() {
		query="INSERT INTO GUERRERO VALUES (?,?,?,?)";
	}
	
	public static void actualizar() {
		query="UPDATE GUERRERO SET  ID_GUERRERO = ?, ID_CLAN = ?, NOMBRE_GUERRERO = ?,EDAD=?" + "WHERE CODIGO_GUERRERO = ?";
	}

	public static void borrar() {
		query="DELETE FROM GUERRERO WHERE CODIGO_GUERRERO = ?;";
	}
	
}
