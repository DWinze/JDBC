package principal;
import java.sql.SQLException;

import Excepciones.DAOException;
import MySQLDAO.MySQLGuerreroDAO;

public class TEST {

	public static void main(String[] args) {
		
		
		Conexion c = new Conexion();
		
		
		try {
			
			c.conectar();
			MySQLGuerreroDAO g = new MySQLGuerreroDAO(c.getJdbcConnection());
			System.out.println(g.buscar(3));
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			
		}
		

	}

}
