package principal;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import Excepciones.DAOException;
import DAO.DAOManager;
import modelo.guerreros.GuerreroTableModel;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GuerrerosFrame extends JFrame {

	private JPanel contentPane;
	private JTextField IDGUERRERO;
	private JTextField ID_CLAN;
	private JTextField NOMBRE_GUERRERO;
	private JTextField EDAD;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GuerrerosFrame frame = new GuerrerosFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GuerrerosFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 732, 491);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIdguerrero = new JLabel("ID_GUERRERO");
		lblIdguerrero.setBounds(25, 108, 72, 14);
		contentPane.add(lblIdguerrero);
		
		JLabel lblIdclan = new JLabel("ID_CLAN");
		lblIdclan.setBounds(25, 153, 46, 14);
		contentPane.add(lblIdclan);
		
		JLabel lblNombreguerrero = new JLabel("NOMBRE_GUERRERO");
		lblNombreguerrero.setBounds(25, 199, 103, 14);
		contentPane.add(lblNombreguerrero);
		
		JLabel lblEdad = new JLabel("EDAD");
		lblEdad.setBounds(25, 247, 46, 14);
		contentPane.add(lblEdad);
		
		IDGUERRERO = new JTextField();
		IDGUERRERO.setBounds(151, 105, 86, 20);
		contentPane.add(IDGUERRERO);
		IDGUERRERO.setColumns(10);
		
		ID_CLAN = new JTextField();
		ID_CLAN.setBounds(151, 150, 86, 20);
		contentPane.add(ID_CLAN);
		ID_CLAN.setColumns(10);
		
		NOMBRE_GUERRERO = new JTextField();
		NOMBRE_GUERRERO.setBounds(151, 193, 86, 20);
		contentPane.add(NOMBRE_GUERRERO);
		NOMBRE_GUERRERO.setColumns(10);
		
		EDAD = new JTextField();
		EDAD.setBounds(151, 244, 86, 20);
		contentPane.add(EDAD);
		EDAD.setColumns(10);
		
		JButton btnCrear = new JButton("CREAR");
		btnCrear.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			}
		});
		btnCrear.setBounds(25, 381, 89, 23);
		contentPane.add(btnCrear);
		
		JButton btnModificar = new JButton("MODIFICAR");
		btnModificar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnModificar.setBounds(161, 381, 101, 23);
		contentPane.add(btnModificar);
		
		JButton btnBorrar = new JButton("BORRAR");
		btnBorrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnBorrar.setBounds(326, 381, 89, 23);
		contentPane.add(btnBorrar);
		
		JButton btnCancelar = new JButton("CANCELAR");
		btnCancelar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnCancelar.setBounds(468, 381, 89, 23);
		contentPane.add(btnCancelar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(302, 69, 360, 245);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID_GUERRERO", "ID_CLAN", "NOMBRE_GUERRERO", "EDAD"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(97);
		table.getColumnModel().getColumn(2).setPreferredWidth(121);
		table.setCellSelectionEnabled(true);
		table.setColumnSelectionAllowed(true);
		table.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		scrollPane.setViewportView(table);
	}
}
