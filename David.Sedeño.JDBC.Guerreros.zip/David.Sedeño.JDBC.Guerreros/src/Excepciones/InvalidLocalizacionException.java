package Excepciones;

public class InvalidLocalizacionException extends Exception {
		
	public InvalidLocalizacionException(){
		super("Error en la localizacion");
		
		}
	
	public InvalidLocalizacionException(String m){
		super("Error en la localizacion" + m);
	}
}
