package Excepciones;

public class OutOfBoundClanException extends Exception {

	public OutOfBoundClanException(String m) {
		super("Id del clan no existente (solo de 1 a 4)" + m);
	}

	public OutOfBoundClanException() {
		super("Id del clan no existente (solo de 1 a 4)");
	}

}
