package DAO;

import java.util.List;
import modelo.guerreros.Clan;

public interface ClanDAO extends DAO<Clan, Integer>{
	
}
