package DAO;

public interface DAOManager {
	ClanDAO getClanDAO();
	GuerreroDAO getGuerreroDAO();
	LocalizacionDAO getLocalizacionDAO();
}
