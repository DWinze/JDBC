package DAO;

import java.util.List;
import modelo.guerreros.Localizacion;

public interface LocalizacionDAO extends DAO<Localizacion, String>{
	
}
