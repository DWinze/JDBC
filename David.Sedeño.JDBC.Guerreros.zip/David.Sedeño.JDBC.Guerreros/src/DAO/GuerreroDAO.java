package DAO;

import java.util.List;
import modelo.guerreros.Guerrero;;

public interface GuerreroDAO extends DAO<Guerrero, Integer>{
	
}
