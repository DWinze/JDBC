package modelo.guerreros;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import DAO.GuerreroDAO;
import Excepciones.DAOException;

public class GuerreroTableModel extends AbstractTableModel{


	private static final long serialVersionUID = 1L;
	private GuerreroDAO guerreroDAO;
	private List<Guerrero> datos = new ArrayList<Guerrero>();
	private String[] columnas = {"ID_GUERRERO","ID_CLAN", "NOMBRE_GUERRERO", "EDAD"};
	
	public GuerreroTableModel(GuerreroDAO dao) throws DAOException {
		this.guerreroDAO = dao;
		this.updateModel();
	}
	
	public void updateModel() throws DAOException {
		datos = guerreroDAO.obtenerTodo();
	}
	
	@Override
	public String getColumnName(int column) {
		switch(column){
		case 0: return "ID_GUERRERO";
		case 1: return "ID_CLAN";
		case 2: return "NOMBRE_GUERRERO";
		case 3: return "EDAD";
		default: return "[mal]";
		}
	}

	@Override
	public int getRowCount() {
		
		return datos.size();
	}

	@Override
	public int getColumnCount() {
		
		return columnas.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Guerrero g = datos.get(rowIndex);
		switch(columnIndex) {
		case 0:
			return g.getId_guerrero();
		case 1:
			return g.getId_clan();
		case 2:
			return g.getNombre_guerrero();
		case 3:
			return g.getEdad();
		
		default:
			return "";
		}
	}

}