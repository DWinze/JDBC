package modelo.guerreros;




public interface Localizable {
	Integer[] IDCLANES = {1,2,3,4};
	String[] PAISES = {"CHINA","JAPON","GER","GROEN"};
	String[] CONTINENTES = {"ASIA","EUROPA"};		
	
	
}
